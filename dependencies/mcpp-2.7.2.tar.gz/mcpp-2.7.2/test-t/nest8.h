/* nest8.h  */

    nest = 8;
#ifndef X8
#include    "nest9.h"
#endif

