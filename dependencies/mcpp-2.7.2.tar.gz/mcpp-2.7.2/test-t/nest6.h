/* nest6.h  */

    nest = 6;

#include    "nest7.h"
