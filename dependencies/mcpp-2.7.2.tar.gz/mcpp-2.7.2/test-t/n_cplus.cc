/* cplus.t:     C++98 pre-defined macro __cplusplus.    */

/*  199711L;    */
    __cplusplus;

