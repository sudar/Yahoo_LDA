/* u_cplus.t:   C++: #undef or #define __cplusplus causes undefined
        behavior.   */

#undef  __cplusplus

