/* header.h */

#define MACRO_abc   abc
