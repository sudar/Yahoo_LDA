/* n_dslcom:    // is a comment of C++ and C99. */
/*  a;  */ 
    a;  // is a comment of C++ and C99

