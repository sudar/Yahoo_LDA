/* nest63.h */
#ifdef  X3F
    nest = 0x3f;
#else
#include "nest64.h"
#endif
