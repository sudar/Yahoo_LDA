/* u_1_12.c:    Undefined behaviors on undefined #include syntax or header-
        name.   */

/* u.1.12:  Argument of #include other than header-name.    */
#include    filename

main( void)
{
    return  0;
}

