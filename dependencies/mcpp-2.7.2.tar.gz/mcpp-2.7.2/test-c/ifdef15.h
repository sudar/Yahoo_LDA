/* ifdef15.h    */

#ifdef  X01
#else
#ifdef  X02
#else
#ifdef  X03
#else
#ifdef  X04
#else
#ifdef  X05
#else
#ifdef  X06
#else
#ifdef  X07
#else
#ifdef  X08
#else
#ifdef  X09
#else
#ifdef  X0A
#else
#ifdef  X0B
#else
#ifdef  X0C
#else
#ifdef  X0D
#else
#ifdef  X0E
#else
#ifdef  X0F
    nest = 0x0f;
#endif  /* X0F  */
#endif  /* X0E  */
#endif  /* X0D  */
#endif  /* X0C  */
#endif  /* X0B  */
#endif  /* X0A  */
#endif  /* X09  */
#endif  /* X08  */
#endif  /* X07  */
#endif  /* X06  */
#endif  /* X05  */
#endif  /* X04  */
#endif  /* X03  */
#endif  /* X02  */
#endif  /* X01  */

